<?php
/**
*Plugin Name: Article Mailer
*Description: دریافت ایمیل کاربران و ارسال خلاصه مقاله به ایمیل کاربران
*Author: mhdibaqri
*Author URI: https://www.instagram.com/mhdibaqri
*/
    if(! defined('AMAILER_PATH'))
        define('AMAILER_PATH', plugin_dir_path(__FILE__));
    if(! defined('AMAILER_URL'))
        define('AMAILER_URL', plugin_dir_url(__FILE__));
    if(! defined('AMAILER_TABLE'))
        define('AMAILER_TABLE', $wpdb->prefix . 'article_mailer_users');

	// check table exists
	if ( !class_exists( 'AMAILER_TABLE' ) )
	{
		class AMAILER_TABLE {
		public function __construct() {
			require( AMAILER_PATH . 'inc/inc-model.php' );
			register_activation_hook( __FILE__, 'article_mailer_new_model' );
		}
		}
		new AMAILER_TABLE();
	}

    require "inc/inc-scripts.php";
    require "tpl/tpl-form.php";
    require "inc/inc-process.php";

    // return html form from get mail
    add_shortcode('article-mailer','mail_form_tpl');

	// execute sender
    require "inc/inc-sender.php";