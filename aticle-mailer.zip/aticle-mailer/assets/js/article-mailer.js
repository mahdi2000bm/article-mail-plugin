let jq = jQuery.noConflict();
let formMailer = document.getElementById("article-mailer");
let msgResponse = document.getElementById("msg-response");
formMailer.addEventListener("submit", form_mailer_click, false);

function form_mailer_click(event)
{
  event.preventDefault();
  let email = document.querySelector("#article-mailer #input-mail").value;

  jq.ajax({
    type: "post",
    url: "/wp-admin/admin-ajax.php",
    data:{
      action: 'record_new_subscribe_form', email: email
    },
    success: function(response){
        let jsonResponse = response.slice(0, -1);
        jsonResponse = JSON.parse(jsonResponse);
        msgResponse.classList.add("response-" + jsonResponse.status);

		msgResponse.innerText = " "
        msgResponse.innerText = jsonResponse.msg
		
		if(jsonResponse.status === "success")
			jq('form#article-mailer').fadeOut("fast"); 
    },
    error: function(response){
        console.log(response)
    }
  });
}