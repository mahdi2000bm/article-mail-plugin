<?php 

function mail_form_tpl(): string
{
    return "<section class='article-mail-form'>" .
        "<div class='article-wrapper'>" .
            "<form id='article-mailer' method='POST' class='article-flex' action=''>" .
                "<input type='text' id='input-mail' name='email' autocomplete='off' placeholder='ایمیل شما...'>" .
                "<input type='submit' value='ارسال'>" .
            "</form>" .
            "<p class='article-mail-response' id='msg-response'></p>".
        "</div>" .
    "</section>";
}