<?php
function article_mailer_sender(): void
{
    global $post;
	$postData = get_post($post->ID);

	// die action
	if(isset($GLOBALS['userEmail']) or $postData->post_type != "post" or empty($postData->guid) or empty($postData->post_title))
        return;

    // Email header
    $headers[] = "MIME-Version: 1.0\r\n";
    $headers[] = "Content-Type: text/html; charset=UTF-8";

    // Users
	global $wpdb;
	$sql = "SELECT user_email FROM ". AMAILER_TABLE;
	$stmt_email = $wpdb->get_results($sql);

	if(empty($stmt_email))
		return;

	foreach($stmt_email as $user){
		$emailTo[] = $user->user_email; 
	}

    // Email Subject
	$subject = get_the_title($post->ID);

    // Email Body
	$content = $postData->post_content;
	$content = apply_filters('the_content', $content);
	$content = wp_trim_words( $content, 45);

	// Return tumbnail url
	$post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
	$thumbnail_url = wp_get_attachment_image_url( $post_thumbnail_id, '400' );

	// Email Body
	$message = '<div style="direction:rtl;background-color: rgba(26,13,77,0.12);border-radius: 16px; padding: 40px;"> <div style="width: 600px; background-color:#fff; margin: auto; border-radius: 12px;"> <img style="width: 100%;border-radius:12px 12px 0 0;" src="'. $thumbnail_url .'" /> <div style="padding: 0 24px 24px;"> <h2 style="margin:16px 0 0; font-weight:700; font-size:24px;color: #10008f;">'. get_the_title($post->ID) .'</h2><div><p style="margin-top: 8px;font-size: 17px">'. $content .'</p><a href="'. $postData->guid .'" style=" background: #10008f; text-decoration: none; color: #fff; font-weight: bold; font-size: 14px; padding: 7px 14px; border-radius: 8px; ">خواندن مقاله</a></div></div></div></div>';

    // Send the mail
    wp_mail( $emailTo, $subject, $message, $headers );

    // Using GLOBALS['var_name']
    $GLOBALS['userEmail'] = $emailTo;
}

// add filter title sender email
add_filter( 'wp_mail_from_name', function($name)
{ 
	return get_bloginfo(); 
});
// trigger action
add_action('save_post', 'article_mailer_sender', 11);