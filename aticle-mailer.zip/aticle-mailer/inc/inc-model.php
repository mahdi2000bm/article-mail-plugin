<?php

function article_mailer_new_model() 
{
    global $wpdb;
	$table_name =  $wpdb->prefix . 'article_mailer_users';

    $sql = "CREATE TABLE $table_name (
		id int NOT NULL AUTO_INCREMENT,
		user_email varchar(100) NOT NULL,
		created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY  (id)
	) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );   
}