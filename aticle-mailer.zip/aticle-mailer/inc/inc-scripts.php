<?php
defined( 'ABSPATH' ) || die('');

function article_mailer_front_scripts()
{
    wp_enqueue_script('article-mailer', AMAILER_URL . 'assets/js/article-mailer.js' , array('jquery') ,  rand(9,9999)  , true);
    wp_enqueue_style('article-mailer', AMAILER_URL . 'assets/css/article-mailer.css' , '' , rand(9,9999) );
}
add_action('wp_enqueue_scripts', 'article_mailer_front_scripts');