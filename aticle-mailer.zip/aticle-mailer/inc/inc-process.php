<?php
add_action('wp_ajax_record_new_subscribe_form', 'article_mailer_save_email');
add_action('wp_ajax_nopriv_record_new_subscribe_form', 'article_mailer_save_email');

function article_mailer_save_email(): void
{
    global $wpdb;
    $email_var= $_POST["email"] ?? "";

    if(is_email($email_var)){
        $mail = sanitize_email( $email_var );
        $data = ['user_email'=>$mail];
        $format = ["%s"];

        // return email if isset
		$sql = "SELECT id FROM ". AMAILER_TABLE ." WHERE user_email = '$mail'";
        $stmt_email = $wpdb->get_results($sql);

        if (empty($stmt_email)){
            $stmt = $wpdb->insert(AMAILER_TABLE , $data ,$format);
            echo json_encode(["status" => "success", "msg" => "ممنون از شما ، با موفقیت ثبت شد!" ]);
        }else {
            echo json_encode(["status" => "fail", "msg" => "ایمیل شما قبلا ثبت شده!"]);
        }
        return;
    }
    echo json_encode(["status" => "fail", "msg" => "ایمیل نامعتبر!"]);
}